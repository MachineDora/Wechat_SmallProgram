//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    logs: [],
    motto111: 'Hello World！！！',
    message:[],
    contents:[],
  },
  //事件处理函数
  clickMe:function(options) {
    let index = options.currentTarget.dataset.index
    wx.navigateTo({
      url: '../text/text',
    })
    wx.setStorage({
      key: 'key',
      data: index,
    })
  },
  click_add_text(){
    wx.showToast({
      title: '哈哈哈',
      icon: 'succes',
      duration: 1000,
      mask: true
    })
  },
  hahaha(){
    wx.showToast({
      title: '牛逼',
      icon: 'succes',
      duration: 1000,
      mask: true
    })
  },
onLoad: function (options){
  var self=this
  wx.getStorageInfo({
    success: function(res) {
      self.setData({
        logs:res.keys
      })
    },
  })
},
  onShow: function () {
    this.onLoad()
    console.log(this.data.logs[0])
  }
})
